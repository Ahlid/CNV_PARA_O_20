package pt.ulisboa.tecnico.meic.cnv.mazerunner.maze.render;

import pt.ulisboa.tecnico.meic.cnv.mazerunner.maze.Maze;

public interface RenderMaze {

	public String render(Maze maze, int velocity);
	
}
