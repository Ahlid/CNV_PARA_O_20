package pt.ulisboa.tecnico.meic.cnv.mazerunner.maze.exceptions;

public class CantGenerateOutputFileException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1557912935765275684L;

	public CantGenerateOutputFileException(String errorMessage) {
		super(errorMessage);
	}
	
}
