export JAVA_HOME=/etc/alternatives/java_sdk_1.7.0
export JAVA_ROOT=/etc/alternatives/java_sdk_1.7.0
export JDK_HOME=/etc/alternatives/java_sdk_1.7.0
export JRE_HOME=/etc/alternatives/java_sdk_1.7.0/jre
export PATH=/etc/alternatives/java_sdk_1.7.0/bin:$PATH
export SDK_HOME=/etc/alternatives/java_sdk_1.7.0
export _JAVA_OPTIONS="-XX:-UseSplitVerifier "$_JAVA_OPTIONS
